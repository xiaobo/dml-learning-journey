"""Run in a NEW writable exercise directory. Requires duckdb and an existing dmlc."""
from pathlib import Path
import json,sys,subprocess,hashlib,csv,math
import duckdb
root=Path(__file__).resolve().parent
exe=Path(sys.argv[1]).resolve()
db=root/'practice.duckdb'
if db.exists(): raise SystemExit('Use a fresh extracted directory; practice.duckdb already exists.')
with duckdb.connect(str(db)) as c:
 for name in ['TABLE_SALES','TABLE_REGION']:
  c.execute('CREATE TABLE '+name+' AS SELECT * FROM read_csv_auto(?)',[str(root/(name+'.csv'))])
 expected=c.execute("SELECT region, sum(amount) sales, sum(CASE WHEN status='completed' THEN amount ELSE 0 END) completed_sales FROM TABLE_SALES WHERE dt_month='2025-02-01' GROUP BY region ORDER BY region").fetchall()
(root/'.dmlc').mkdir(exist_ok=True)
(root/'.dmlc/connections.json').write_text(json.dumps({'connections':[{'id':'default','type':'duckdb','url':'jdbc:dmlc:duckdb:'+db.as_posix(),'readOnly':False}],'defaultConnection':'default'}))
report={'compiler_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'version':subprocess.check_output([str(exe),'--version'],text=True),'runs':{}}
for mode,flags in [('compile',['--compile','--strict','--output-dir=gen']),('validate',['--validate-only','--connection=default']),('execute',['--connection=default'])]:
 args=[str(exe),'--workspace='+str(root),'--model='+str(root/'model.dml'),'--output-format=json',*flags,str(root/'query.sql')]
 proc=subprocess.run(args,cwd=root,capture_output=True,encoding='utf-8',timeout=90)
 (root/(mode+'.json')).write_text(proc.stdout,encoding='utf-8');(root/(mode+'.stderr.txt')).write_text(proc.stderr,encoding='utf-8')
 report['runs'][mode]={'exit':proc.returncode,'flags':flags}
 if mode=='execute' and proc.returncode==0:
  rows=json.loads(proc.stdout)
  wanted=list(csv.DictReader((root/'expected.csv').open()))
  assert len(rows)==len(wanted)==2
  assert len({x['region'] for x in rows})==2
  for w in wanted:
   row=next(x for x in rows if x['region']==w['region']);assert set(row)==set(w)
   for k,v in w.items():
    if k!='region':assert row[k] is not None and math.isclose(float(row[k]),float(v),rel_tol=1e-9,abs_tol=1e-9),(k,row[k],v)
  for region,sales,completed in expected:
   actual=next(x for x in rows if x['region']==region);assert actual['sales']==sales and actual['completed_sales']==completed
  report['result_matches']=True
(root/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
assert report.get('result_matches') and all(x['exit']==0 for x in report['runs'].values()),'Review diagnostics; do not treat a strict finding as a pass.'
