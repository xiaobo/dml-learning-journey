import java.sql.*;
import java.util.*;
public class VerifyJdbc {
 static void check(boolean ok,String message){if(!ok)throw new IllegalStateException(message);}
 static double scalar(Connection c,String sql) throws Exception{try(Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){check(r.next(),"Missing row: "+sql);double v=r.getDouble(1);check(!r.wasNull()&&!r.next(),"Expected one non-null row");return v;}}
 static void rows(Connection c,String sql,String[][] want)throws Exception{try(Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){int i=0;while(r.next()){check(i<want.length,"Extra row");check(r.getMetaData().getColumnCount()==want[i].length,"Column count");for(int j=0;j<want[i].length;j++)check((Objects.equals(r.getString(j+1),want[i][j]) || Objects.equals(r.getString(j+1),want[i][j]+".0")),"Unexpected value "+r.getString(j+1));i++;}check(i==want.length,"Missing rows");}}
 public static void main(String[] args)throws Exception{
  check(args.length==2,"Arguments: model directory, JDBC driver directory");Class.forName("com.datoai.jdbc.DmlDriver");
  try(Connection c=DriverManager.getConnection("jdbc:dmlc:duckdb::memory:?modelPath="+args[0]+"&driverPath="+args[1])){
   try(Statement s=c.createStatement()){s.execute("SET TimeZone='UTC'");s.execute("CREATE TABLE t(id INTEGER,value DOUBLE)");s.execute("INSERT INTO t VALUES (1,10),(2,20)");}
   String[] physical={"SELECT value FROM t WHERE id = ?","SELECT SUM(value) * ? FROM t"};double[] wanted={20,60};
   for(int i=0;i<physical.length;i++){try(PreparedStatement p=c.prepareStatement(physical[i])){p.setDouble(1,2);try(ResultSet r=p.executeQuery()){check(r.next()&&r.getDouble(1)==wanted[i]&&!r.next(),"Physical binding mismatch");}}}
   System.out.println("physical_binding: passed (20,60)");
   for(String q:new String[]{"SELECT AGG(sales) FROM MODEL WHERE id = ?","SELECT AGG(sales) * ? FROM MODEL"}){boolean failed=false;try(PreparedStatement p=c.prepareStatement(q)){p.setDouble(1,2);try(ResultSet rs=p.executeQuery()){while(rs.next()){} }}catch(SQLException e){failed=true;System.out.println("semantic_binding_expected_failure: "+e.getMessage().replace('\n',' '));}check(failed,"Semantic binding unexpectedly succeeded: revise documented boundary");}
   check(scalar(c,"SELECT AGG(sales) FROM MODEL WHERE id = 2")==20,"Literal filter");check(scalar(c,"SELECT AGG(sales) * 2 FROM MODEL")==60,"Literal formula");
   System.out.println("semantic_literals: passed (20,60)");
   rows(c,"SELECT timezone('America/New_York', TIMESTAMPTZ '2024-01-01 02:00:00+00')",new String[][]{{"2023-12-31 21:00:00"}});
   rows(c,"SELECT timezone('America/New_York',TIMESTAMPTZ '2024-11-03 05:30:00+00'),timezone('America/New_York',TIMESTAMPTZ '2024-11-03 06:30:00+00')",new String[][]{{"2024-11-03 01:30:00","2024-11-03 01:30:00"}});
   check(scalar(c,"SELECT (epoch(timezone('America/New_York',TIMESTAMP '2024-03-11 00:00:00'))-epoch(timezone('America/New_York',TIMESTAMP '2024-03-10 00:00:00')))/3600")==23,"Spring day length");
   check(scalar(c,"SELECT (epoch(timezone('America/New_York',TIMESTAMP '2024-11-04 00:00:00'))-epoch(timezone('America/New_York',TIMESTAMP '2024-11-03 00:00:00')))/3600")==25,"Fall day length");
   check(scalar(c,"SELECT count(*) FROM (VALUES(TIMESTAMPTZ '2024-03-10 04:59:59+00'),(TIMESTAMPTZ '2024-03-10 05:00:00+00'),(TIMESTAMPTZ '2024-03-11 03:59:59+00'),(TIMESTAMPTZ '2024-03-11 04:00:00+00')) t(ts) WHERE ts>=timezone('America/New_York',TIMESTAMP '2024-03-10 00:00:00') AND ts<timezone('America/New_York',TIMESTAMP '2024-03-11 00:00:00')")==2,"Half-open business day");
   System.out.println("timezone: passed (midnight, repeated hour, 23/25-hour days, half-open filter)");
  }
 }
}
