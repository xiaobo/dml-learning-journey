"""Run: python verify.py --dmlc PATH --output NEW_DIRECTORY. Requires duckdb."""
import argparse,hashlib,json,math,shutil,subprocess
from pathlib import Path
import duckdb
if not __debug__: raise SystemExit("Run without -O: result checks must remain enabled.")
p=argparse.ArgumentParser();p.add_argument('--dmlc',required=True);p.add_argument('--output',required=True);a=p.parse_args()
exe=Path(a.dmlc).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);src=Path(__file__).resolve().parent
report={'compiler':subprocess.check_output([str(exe),'--version'],text=True),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'duckdb':duckdb.__version__,'cases':{}}
def equal(actual,wanted):
 if isinstance(wanted,list):return isinstance(actual,list) and len(actual)==len(wanted) and all(equal(x,y) for x,y in zip(actual,wanted))
 if isinstance(wanted,dict):return isinstance(actual,dict) and actual.keys()==wanted.keys() and all(equal(actual[k],v) for k,v in wanted.items())
 if isinstance(wanted,(float,int)):return isinstance(actual,(float,int)) and math.isclose(actual,wanted,rel_tol=1e-9,abs_tol=1e-9)
 return actual==wanted
for name in ['compound','range','fixed','ytd']:
 d=out/name;shutil.copytree(src/name,d);db=d/'data.duckdb'
 with duckdb.connect(str(db)) as c:c.execute((d/'setup.sql').read_text())
 (d/'.dmlc').mkdir();(d/'.dmlc/connections.json').write_text(json.dumps({'connections':[{'id':'practice','type':'duckdb','url':'jdbc:dmlc:duckdb:'+db.as_posix(),'readOnly':False}],'defaultConnection':'practice'}))
 cfg=json.loads((d/'expected.json').read_text());runs={};report['cases'][name]=runs
 def run(q,mode,tag=''):
  flags=['--compile','--strict','--output-dir='+str(d/'generated')] if mode=='compile' else ['--validate-only'] if mode=='validate' else []
  cmd=[str(exe),'--workspace='+str(d),'--model='+str(d/'model.dml'),'--output-format=json',*flags,str(d/(q+'.sql'))]
  p=subprocess.run(cmd,cwd=d,capture_output=True,encoding='utf-8',timeout=90);key=tag+q+'-'+mode
  (d/(key+'.stdout.json')).write_text(p.stdout,encoding='utf-8');(d/(key+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
  runs[key]={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};return p
 for q,w in cfg['expected'].items():
  for mode in ['compile','validate','execute']:
   proc=run(q,mode);assert proc.returncode==0,(name,q,mode,proc.stdout,proc.stderr)
  assert equal(json.loads(proc.stdout),w),(name,q,json.loads(proc.stdout),w)
 for q,text in cfg.get('expected_errors',{}).items():
  proc=run(q,'compile');assert proc.returncode!=0 and text in proc.stdout+proc.stderr,(name,q,proc.stdout,proc.stderr)
 if 'break' in cfg:
  with duckdb.connect(str(db)) as c:c.execute(cfg['break'])
  proc=run('normal','validate','broken-');assert proc.returncode!=0 and 'DIMENSION_NOT_UNIQUE' in proc.stdout+proc.stderr,(name,'duplicate not detected',proc.stdout)
  with duckdb.connect(str(db)) as c:c.execute(cfg['repair'])
  proc=run('normal','validate','repaired-');assert proc.returncode==0,proc.stdout
  proc=run('normal','execute','repaired-');assert proc.returncode==0 and equal(json.loads(proc.stdout),cfg['expected']['normal'])
 (out/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(name,'passed',flush=True)
report['passed']=True;(out/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('All result, row-membership and expected-failure checks passed.')
