# 可运行的 DML 业务案例

需要已有 dmlc、Python 3 和 duckdb==1.5.5。目录名与模型文件名是示例的一部分。

```powershell
py -m pip install duckdb==1.5.5
py verify.py --dmlc C:/path/to/dmlc.exe --output C:/path/to/new-practice-output
```

output 必须尚不存在。脚本创建该目录、练习数据库及本地连接配置，不读取业务数据。再次运行使用新的 output。不要使用 python -O；它会禁用断言，脚本会拒绝运行。

compound：复合键查找，重复目标键后验证失败，修复后通过。
range：相邻有效期、交界点、重叠验证失败及修复。
fixed：固定分母范围、完整输出行检查、按时间累计和筛选影响。
ytd：二月累计比率与普通收入、无日期上下文失败、全年日历月份与 NULL。

脚本检查每条查询的严格编译、validate-only、执行和完整结果；预期失败需出现指定诊断。原始 stdout、stderr、生成 SQL 和 results.json 留在 output 中。检查是独立操作，不提供同一快照保证。

## 可选 JDBC 参数与时区配方

需要 JDK（支持直接运行 Java 源文件）、已有的 dmlc shaded jar 与配套 DuckDB JDBC jar。将下面的路径替换为真实安装路径；Windows classpath 使用分号，其他系统使用冒号。

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```

此程序使用内存库，显式设定 UTC 会话；检查物理 SQL 参数绑定成功、语义查询占位符预期失败、字面量对照成功，以及 America/New_York 的业务日边界。失败会抛出异常、非零退出。预期的语义解析错误会输出诊断，最后仍须有 timezone: passed。不附带或下载第三方运行时。

## 阅读范围

verification-summary.json 记录本次结果和工具身份，不保证其他版本或数据库行为一致。模型粒度与字段类型需要按自己的数据验证。修改 expected.json 不能替代检查业务口径。
