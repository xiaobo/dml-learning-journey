# 运行 DML 业务示例

解压后，先按月、按地区查净收入，再用扣除退款的模型运行相同的查询。最后一条查询对照二月和一月的净收入。

```sh
cd net-revenue
dmlc -q setup.sql
dmlc -q --with-validation --model=model.dml monthly.sql
dmlc -q --with-validation --model=model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml monthly.sql
dmlc -q --with-validation --model=after-refunds/model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml previous-month.sql
cd ..
```

要自动核对五个案例，在项目根目录打开 PowerShell，运行以下命令。每次选择新的输出目录。

```powershell
./verify.ps1 -Output practice-output
```

## 可选的 JDBC 检查

准备 JDK、包含依赖的 dmlc JAR 和匹配的 DuckDB JDBC 驱动。把下面的路径替换成自己的安装路径。Unix 的类路径用冒号分隔。

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```
