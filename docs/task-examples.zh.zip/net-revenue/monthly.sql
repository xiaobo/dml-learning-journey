SELECT dt_month, AGG(净收入) FROM MODEL GROUP BY dt_month ORDER BY dt_month
