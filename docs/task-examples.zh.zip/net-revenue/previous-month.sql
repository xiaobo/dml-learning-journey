SELECT AGG(净收入), AGG(上月净收入) FROM MODEL WHERE dt_month='2025-02-01'
