SELECT region AS 地区, sum(amount) AS 销售额,
       sum(CASE WHEN status='completed' THEN amount ELSE 0 END) AS 已完成订单销售额
FROM TABLE_SALES WHERE dt_month='2025-02-01' GROUP BY region ORDER BY region;
