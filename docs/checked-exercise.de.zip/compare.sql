SELECT region AS Region, sum(amount) AS Umsatz,
       sum(CASE WHEN status='completed' THEN amount ELSE 0 END) AS UmsatzAbgeschlossenerBestellungen
FROM TABLE_SALES WHERE dt_month='2025-02-01' GROUP BY region ORDER BY region;
