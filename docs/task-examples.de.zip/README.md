# Geschäftsbeispiele ausführen

Führen Sie im entpackten Ordner den Monatsbericht und den Bericht nach Region aus. Wiederholen Sie die Abfragen mit dem Modell, das Erstattungen abzieht. Die letzte Abfrage vergleicht Februar mit Januar.

```sh
cd net-revenue
dmlc -q setup.sql
dmlc -q --with-validation --model=model.dml monthly.sql
dmlc -q --with-validation --model=model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml monthly.sql
dmlc -q --with-validation --model=after-refunds/model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml previous-month.sql
cd ..
```

Um alle fünf Beispiele zu prüfen, führen Sie in PowerShell den folgenden Befehl im Projektordner aus. Wählen Sie bei jedem Durchlauf einen neuen Ausgabeordner.

```powershell
./verify.ps1 -Output practice-output
```

## Optionaler JDBC-Test

Sie benötigen ein JDK, die installierte dmlc-JAR-Datei mit Abhängigkeiten und den passenden DuckDB-JDBC-Treiber. Ersetzen Sie die Pfade. Unter Unix trennen Sie die Einträge im Klassenpfad mit einem Doppelpunkt.

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```
