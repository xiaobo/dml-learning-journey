SELECT AGG(Nettoerlös), AGG(NettoerlösVormonat) FROM MODEL WHERE dt_month='2025-02-01'
