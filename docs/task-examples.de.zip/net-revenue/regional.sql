SELECT Region, AGG(Nettoerlös) FROM MODEL GROUP BY Region ORDER BY Region
