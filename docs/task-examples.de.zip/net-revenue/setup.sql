CREATE TABLE orders(order_id INTEGER, report_month DATE, region VARCHAR, amount INTEGER, refund INTEGER);
INSERT INTO orders VALUES
  (1, DATE '2025-01-01', 'East', 100, 10),
  (2, DATE '2025-02-01', 'East', 150, 30),
  (3, DATE '2025-02-01', 'West', 80, 0);
