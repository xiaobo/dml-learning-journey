SELECT dt_month, AGG(Nettoerlös) FROM MODEL GROUP BY dt_month ORDER BY dt_month
