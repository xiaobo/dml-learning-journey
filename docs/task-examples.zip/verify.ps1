param([string]$Dmlc='dmlc',[string]$Output='practice-output')
. "$PSScriptRoot/checks.ps1"
$out=New-Output $Output
$report=@{compiler=(& $Compiler --version | Out-String);sha256=(Get-FileHash $Compiler).Hash;cases=@{}}
foreach ($case in 'compound','range','fixed','ytd','net-revenue') {
    $dir=Join-Path $out $case
    $null=New-Output $dir
    Copy-Item "$PSScriptRoot/$case/.dmlc" $dir -Recurse -Force
    Copy-Item "$PSScriptRoot/$case/*.sql","$PSScriptRoot/$case/model.dml","$PSScriptRoot/$case/expected.json" $dir
    Push-Location $dir
    try {
        Run-Physical setup.sql
        $cfg=Get-Content expected.json -Raw -Encoding utf8 | ConvertFrom-Json
        $runs=@{}; $report.cases[$case]=$runs
        function Check-Query($Query,$Expected,$Prefix) {
            $base="$Prefix$Query"
            $argsBase=@('--model=model.dml','--json',"$Query.sql")
            $runs["$base-compile"]=Invoke-Check "$base-compile" ($argsBase+@('-c','--strict',"--artifacts=$base-generated"))
            $runs["$base-validate"]=Invoke-Check "$base-validate" ($argsBase+'--validate')
            $runs["$base-execute"]=Invoke-Check "$base-execute" ($argsBase+@('-q','--with-validation',"--output=$base-rows.json"))
            Assert-Rows @(Get-Rows "$base-rows.json") @($Expected)
        }
        foreach ($q in $cfg.expected.psobject.Properties) { Check-Query $q.Name $q.Value '' }
        if ($cfg.after_refunds) {
            Copy-Item "$PSScriptRoot/$case/after-refunds/model.dml" model.dml -Force
            foreach ($q in $cfg.after_refunds.psobject.Properties) { Check-Query $q.Name $q.Value 'after-' }
        }
        foreach ($q in $cfg.expected_errors.psobject.Properties) {
            $tag="$($q.Name)-compile"
            $runs[$tag]=Invoke-Check $tag @('-c','--strict','--json','--model=model.dml',"$($q.Name).sql") -ExpectFailure
            if (-not ((Get-Content "$tag.stdout.json","$tag.stderr.txt" -Raw) -join '').Contains($q.Value)) { throw "Missing diagnostic: $($q.Value)" }
        }
        if ($cfg.break) {
            $cfg.break | Set-Content break.sql; Run-Physical break.sql
            $runs['broken-normal-validate']=Invoke-Check broken @('--validate','--json','--model=model.dml','normal.sql') -ExpectFailure
            $issues=(Get-Content broken.stdout.json -Raw | ConvertFrom-Json).data
            if ($issues.status -ne 'violated' -or !$issues.issues) { throw 'Missing validation issue' }
            if ($case -eq 'compound') {
                if ('duplicate_key' -notin $issues.issues.kind) {throw 'Missing duplicate_key'}
                'SELECT label, SUM(amount) AS sales FROM FACT JOIN DIM USING (id, region) GROUP BY label ORDER BY label' | Set-Content joined.sql
                $null=Invoke-Check joined @('-q','joined.sql','--output=joined.json')
                Assert-Rows @(Get-Rows joined.json) @([pscustomobject]@{label='East';sales=20},[pscustomobject]@{label='West';sales=20})
            }
            $cfg.repair | Set-Content repair.sql; Run-Physical repair.sql
            Check-Query normal $cfg.expected.normal 'repaired-'
        }
        Write-Host "$case passed"
    } finally { Pop-Location }
}
$report.passed=$true; Save-Report $report (Join-Path $out results.json)
