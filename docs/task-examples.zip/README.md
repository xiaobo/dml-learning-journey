# 可运行的 DML 业务案例

安装 dmlc 后，在解压目录中运行：

```sh
cd net-revenue
dmlc -q setup.sql
dmlc -q --with-validation --model=model.dml monthly.sql
dmlc -q --with-validation --model=model.dml regional.sql
cd ..
```

其他案例也在各自的目录中运行 setup.sql，再运行该目录中的报表查询。要自动核对全部案例，请在 PowerShell 中运行：

```powershell
./verify.ps1 -Output practice-output
```

每次使用新的输出目录。脚本在该目录里建立练习数据库，保存查询结果和诊断信息。

compound：复合键查找，重复目标键后验证失败，修复后通过。
range：相邻有效期、交界点、重叠验证失败及修复。
fixed：固定分母范围、完整输出行检查、按时间累计和筛选影响。
ytd：二月累计比率与普通收入、无日期上下文失败、全年日历月份与 NULL。

脚本检查每条查询的严格编译、验证、执行和完整结果；预期失败需出现指定诊断。原始 stdout、stderr、生成 SQL 和 results.json 留在 output 中。检查是独立操作，不提供同一快照保证。

## 可选 JDBC 参数与时区配方

需要 JDK（支持直接运行 Java 源文件）、已有的 dmlc shaded jar 与配套 DuckDB JDBC jar。将下面的路径替换为真实安装路径；Windows classpath 使用分号，其他系统使用冒号。

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```

此程序使用内存库，显式设定 UTC 会话；检查物理 SQL 和语义查询的参数绑定、字面量对照，以及 America/New_York 的业务日边界。失败会抛出异常并非零退出。不附带或下载第三方运行时。

## 阅读范围

verification-summary.json 记录本次结果和工具身份，不保证其他版本或数据库行为一致。模型粒度与字段类型需要按自己的数据验证。修改 expected.json 不能替代检查业务口径。

net-revenue：先按月份、地区分别查收入，再改一处公式扣除退款，用原来的两条查询核对每一行结果。
