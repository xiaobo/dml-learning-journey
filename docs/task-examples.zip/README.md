# Run the business examples

In the extracted folder, run the monthly and regional reports. Then run the same queries with refunds deducted. The last query compares February with January.

```sh
cd net-revenue
dmlc -q setup.sql
dmlc -q --with-validation --model=model.dml monthly.sql
dmlc -q --with-validation --model=model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml monthly.sql
dmlc -q --with-validation --model=after-refunds/model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml previous-month.sql
cd ..
```

To check all five cases in PowerShell, run the following from the project folder. Choose a new output folder for each run.

```powershell
./verify.ps1 -Output practice-output
```

## Optional JDBC check

Use a JDK, the installed dmlc shaded JAR and its matching DuckDB JDBC driver. Replace both classpath entries and the driver directory. On Unix use a colon between classpath entries.

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```
