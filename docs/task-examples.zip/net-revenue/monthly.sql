SELECT dt_month, AGG(net_revenue) FROM MODEL GROUP BY dt_month ORDER BY dt_month
