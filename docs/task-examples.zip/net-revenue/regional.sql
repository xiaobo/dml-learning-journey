SELECT region, AGG(net_revenue) FROM MODEL GROUP BY region ORDER BY region
