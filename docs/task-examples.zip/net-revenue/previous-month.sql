SELECT AGG(net_revenue), AGG(previous_month_net_revenue) FROM MODEL WHERE dt_month='2025-02-01'
