CREATE TABLE orders(order_id INTEGER, report_month VARCHAR, region VARCHAR, amount INTEGER, refund INTEGER);
INSERT INTO orders VALUES
  (1, 'Jan', 'East', 100, 10),
  (2, 'Feb', 'East', 150, 30),
  (3, 'Feb', 'West', 80, 0);
