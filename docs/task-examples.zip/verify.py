"""Run: python verify.py --dmlc PATH --output NEW_DIRECTORY. Requires duckdb."""
import argparse,hashlib,json,math,shutil,subprocess
from pathlib import Path
import duckdb
if not __debug__: raise SystemExit("Run without -O: result checks must remain enabled.")
p=argparse.ArgumentParser();p.add_argument('--dmlc',required=True);p.add_argument('--output',required=True);a=p.parse_args()
exe=Path(a.dmlc).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);src=Path(__file__).resolve().parent
report={'compiler':subprocess.check_output([str(exe),'--version'],text=True),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'duckdb':duckdb.__version__,'cases':{}}
def equal(actual,wanted):
 if isinstance(wanted,list):return isinstance(actual,list) and len(actual)==len(wanted) and all(equal(x,y) for x,y in zip(actual,wanted))
 if isinstance(wanted,dict):return isinstance(actual,dict) and actual.keys()==wanted.keys() and all(equal(actual[k],v) for k,v in wanted.items())
 if isinstance(wanted,(float,int)):return isinstance(actual,(float,int)) and math.isclose(actual,wanted,rel_tol=1e-9,abs_tol=1e-9)
 return actual==wanted
for name in ['compound','range','fixed','ytd','net-revenue']:
 d=out/name;shutil.copytree(src/name,d);db=d/'data.duckdb'
 with duckdb.connect(str(db)) as c:c.execute((d/'setup.sql').read_text())
 (d/'.dmlc').mkdir();(d/'.dmlc/connections.json').write_text(json.dumps({'connections':[{'id':'practice','type':'duckdb','url':'jdbc:dmlc:duckdb:'+db.as_posix(),'readOnly':False}],'defaultConnection':'practice'}))
 cfg=json.loads((d/'expected.json').read_text());runs={};report['cases'][name]=runs
 def run(q,mode,tag=''):
  flags=['--compile','--strict','--artifacts='+str(d/(tag+q+'-generated'))] if mode=='compile' else ['--validate'] if mode=='validate' else ['--output='+str(d/(tag+q+'-rows.json'))]
  cmd=[str(exe),'--workspace='+str(d),'--model='+str(d/'model.dml'),'--json',*flags,str(d/(q+'.sql'))]
  p=subprocess.run(cmd,cwd=d,capture_output=True,encoding='utf-8',timeout=90);key=tag+q+'-'+mode
  (d/(key+'.stdout.json')).write_text(p.stdout,encoding='utf-8');(d/(key+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
  p.rows=json.loads((d/(tag+q+'-rows.json')).read_text()) if mode=='execute' and p.returncode==0 else None
  runs[key]={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};return p
 for q,w in cfg['expected'].items():
  for mode in ['compile','validate','execute']:
   proc=run(q,mode);assert proc.returncode==0,(name,q,mode,proc.stdout,proc.stderr)
  assert equal(proc.rows,w),(name,q,proc.rows,w)
 if name == 'net-revenue':
  model = d / 'model.dml'
  before = 'net_revenue: SUM({amount})'
  after = 'net_revenue: SUM({amount}) - SUM({refund})'
  original = model.read_text()
  assert original.count(before) == 1
  model.write_text(original.replace(before, after))
  for q, wanted in cfg['after_refunds'].items():
   for mode in ['compile', 'validate', 'execute']:
    proc = run(q, mode, 'after-')
    assert proc.returncode == 0, (q, mode, proc.stdout, proc.stderr)
   assert equal(proc.rows, wanted), (q, proc.rows, wanted)
 for q,text in cfg.get('expected_errors',{}).items():
  proc=run(q,'compile');assert proc.returncode!=0 and text in proc.stdout+proc.stderr,(name,q,proc.stdout,proc.stderr)
 if 'break' in cfg:
  with duckdb.connect(str(db)) as c:c.execute(cfg['break'])
  proc=run('normal','validate','broken-');assert proc.returncode!=0 and json.loads(proc.stdout).get('data',{}).get('status')=='violated' and bool(json.loads(proc.stdout)['data'].get('issues')),(name,'duplicate not detected',proc.stdout)
  if name == 'compound':
   issues = json.loads(proc.stdout)['data']['issues']
   assert any(issue['kind'] == 'duplicate_key' for issue in issues), issues
   with duckdb.connect(str(db)) as c:
    joined = c.execute('SELECT label, SUM(amount) FROM FACT JOIN DIM USING (id, region) GROUP BY label ORDER BY label').fetchall()
   assert joined == [('East', 20), ('West', 20)], joined
  with duckdb.connect(str(db)) as c:c.execute(cfg['repair'])
  proc=run('normal','validate','repaired-');assert proc.returncode==0,proc.stdout
  proc=run('normal','execute','repaired-');assert proc.returncode==0 and equal(proc.rows,cfg['expected']['normal'])
 (out/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(name,'passed',flush=True)
report['passed']=True;(out/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('All result, row-membership and expected-failure checks passed.')
