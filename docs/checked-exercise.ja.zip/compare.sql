SELECT region AS 地域, sum(amount) AS 売上高,
       sum(CASE WHEN status='completed' THEN amount ELSE 0 END) AS 完了注文の売上高
FROM TABLE_SALES WHERE dt_month='2025-02-01' GROUP BY region ORDER BY region;
