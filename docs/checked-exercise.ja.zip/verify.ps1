﻿param([string]$Dmlc='dmlc')
. "$PSScriptRoot/checks.ps1"
Push-Location $PSScriptRoot
try {
    Run-Physical setup.sql
    $runs=@{}
    $runs.compile=Invoke-Check compile @('-c','--strict','--model=model.dml','--artifacts=gen','--json','query.sql')
    $runs.validate=Invoke-Check validate @('--validate','--model=model.dml','--json','query.sql')
    $runs.execute=Invoke-Check execute @('-q','--with-validation','--model=model.dml','--replace','--output=rows.json','query.sql')
    $null=Invoke-Check oracle @('-q','--replace','--output=oracle.json','compare.sql')
    $rows=@(Get-Rows rows.json)
    $expected=@(Import-Csv expected.csv -Encoding UTF8)
    foreach ($row in $expected) { foreach ($key in $row.psobject.Properties.Name) {if ($key -ne '地域') {$row.$key=[double]$row.$key}} }
    Assert-Rows $rows $expected
    Assert-Rows @($rows | Select-Object 地域,売上高,完了注文の売上高) @(Get-Rows oracle.json)
    Save-Report @{compiler_sha256=(Get-FileHash $Compiler).Hash;version=(& $Compiler --version | Out-String);runs=$runs;result_matches=$true} verification.json
    Write-Host 'Sales report passed.'
} finally {Pop-Location}
