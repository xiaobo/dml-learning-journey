$ErrorActionPreference = 'Stop'
$Compiler = (Get-Command $Dmlc -CommandType Application -ErrorAction Stop).Source
function Invoke-Check($Name, [string[]]$Options, [switch]$ExpectFailure) {
    # Windows PowerShell treats redirected stderr as an error even on successful queries.
    $ErrorActionPreference = 'Continue'
    $PSNativeCommandUseErrorActionPreference = $false
    & $Compiler @Options > "$Name.stdout.json" 2> "$Name.stderr.txt"
    $status = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if (($status -ne 0) -ne $ExpectFailure.IsPresent) {
        throw "$Name exited $status. $(Get-Content "$Name.stderr.txt" -Raw) $(Get-Content "$Name.stdout.json" -Raw)"
    }
    return $status
}
function Get-Rows($File) {
    $rows = Get-Content -LiteralPath $File -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($row in $rows) { $row }
}
function Assert-Rows($Actual, $Expected) {
    if ($Actual.Count -ne $Expected.Count) { throw "Row count: $($Actual.Count), expected $($Expected.Count)" }
    for ($i=0; $i -lt $Expected.Count; $i++) {
        $a=$Actual[$i]; $e=$Expected[$i]
        if (Compare-Object @($a.psobject.Properties.Name) @($e.psobject.Properties.Name)) { throw "Unexpected columns in row $i" }
        foreach ($key in $e.psobject.Properties.Name) {
            $v=$a.$key; $w=$e.$key
            if ($null -eq $v -or $null -eq $w) { if ($null -eq $v -and $null -eq $w) {continue} }
            elseif ($w -is [ValueType] -and $w -isnot [bool]) { if ([Math]::Abs([double]$v-[double]$w) -le 1e-9*[Math]::Max(1,[Math]::Abs([double]$w))) {continue} }
            elseif ($v -ceq $w) { continue }
            throw "Row $i, $key is '$v'; expected '$w'"
        }
    }
}
function Save-Report($Value,$File) { $Value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $File -Encoding utf8 }
function New-Output($Path) { (New-Item -ItemType Directory -Path $Path -ErrorAction Stop).FullName }
function Run-Physical($File) { $null=Invoke-Check ([IO.Path]::GetFileNameWithoutExtension($File)) @('-q',$File) }
