SELECT 店舗番号, AGG(注文件数), AGG(注文日数)
FROM repurchase
GROUP BY 店舗番号
ORDER BY 店舗番号
