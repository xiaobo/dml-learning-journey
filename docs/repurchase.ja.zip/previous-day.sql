SELECT AGG(注文件数), AGG(前日の注文件数)
FROM repurchase
WHERE dt_date = '2025-02-04'
