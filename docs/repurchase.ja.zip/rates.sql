SELECT AGG(注文店舗数), AGG(注文件数で数えたリピート店舗数), AGG(注文日数で数えたリピート店舗数),
       AGG(注文件数で数えたリピート購入率), AGG(注文日数で数えたリピート購入率)
FROM repurchase
