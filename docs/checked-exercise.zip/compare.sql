SELECT region, sum(amount) AS sales,
       sum(CASE WHEN status='completed' THEN amount ELSE 0 END) AS completed_sales
FROM TABLE_SALES WHERE dt_month='2025-02-01' GROUP BY region ORDER BY region;
