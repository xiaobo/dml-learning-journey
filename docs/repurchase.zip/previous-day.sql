SELECT AGG(order_count), AGG(previous_day_order_count)
FROM repurchase
WHERE dt_date = '2025-02-04'
