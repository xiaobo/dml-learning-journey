param([string]$Dmlc='dmlc',[string]$Output='repurchase-output')
. "$PSScriptRoot/checks.ps1"
$out=New-Output $Output
$expected=Get-Content "$PSScriptRoot/results.json" -Encoding UTF8 -Raw | ConvertFrom-Json
$names=Get-Content "$PSScriptRoot/names.json" -Encoding UTF8 -Raw | ConvertFrom-Json
foreach ($name in 'original','move','split') {
    $dir=New-Output (Join-Path $out $name)
    Copy-Item "$PSScriptRoot/.dmlc" $dir -Recurse -Force
    Copy-Item "$PSScriptRoot/*.sql","$PSScriptRoot/*.csv","$PSScriptRoot/*.dml" $dir
    Push-Location $dir
    try {
        Run-Physical setup.sql
        if ($name -ne 'original') { Run-Physical "$name.sql" }
        'SELECT SUM(units) AS units FROM receipts' | Set-Content units.sql
        $null=Invoke-Check units @('-q','--output=units.json','units.sql')
        if ((Get-Rows units.json).units -ne 8) {throw 'Total units changed'}
        $null=Invoke-Check compare @('-q','--output=oracle.json','compare.sql')
        foreach ($q in 'stores','rates') { $null=Invoke-Check $q @('-q','--with-validation','--model=repurchase.dml',"--output=$q.json","$q.sql") }
        $stores=@(Get-Rows stores.json); $rates=@(Get-Rows rates.json); $oracle=@(Get-Rows oracle.json)
        Assert-Rows $stores @($expected.$name.stores)
        Assert-Rows $rates @($expected.$name.rates)
        $translated = foreach ($row in $oracle) {
            $values = [ordered]@{}
            foreach ($key in 'store_id','order_count','purchase_days') { $values[$names.$key] = $row.$key }
            [pscustomobject]$values
        }
        Assert-Rows $stores @($translated)
        $null=Invoke-Check day @('-q','--with-validation','--model=repurchase.dml','--output=day.json','previous-day.sql')
        $day=Get-Rows day.json
        $today,$prior=switch ($name) { original {2;4} move {3;3} split {3;5} }
        if ($day.($names.order_count) -ne $today -or $day.($names.previous_day_order_count) -ne $prior) {throw "Previous-day result differs in $name"}
        $orders=@($oracle | Where-Object repeat_by_order).Count
        $days=@($oracle | Where-Object repeat_by_day).Count
        if ($rates[0].($names.active_stores) -ne $oracle.Count -or $rates[0].($names.repeat_purchase_by_orders) -ne $orders -or $rates[0].($names.repeat_purchase_by_days) -ne $days -or $rates[0].($names.repeat_purchase_rate_by_orders) -ne $orders/$oracle.Count -or $rates[0].($names.repeat_purchase_rate_by_days) -ne $days/$oracle.Count) {throw "SQL disagrees with DML in $name"}
        Write-Host "$name passed"
    } finally {Pop-Location}
}
