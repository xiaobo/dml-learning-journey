SELECT AGG(active_stores), AGG(repeat_by_order), AGG(repeat_by_day),
       AGG(repeat_purchase_rate_by_order_count), AGG(repeat_purchase_rate_by_purchase_days)
FROM repurchase
