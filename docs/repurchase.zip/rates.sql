SELECT AGG(active_stores), AGG(repeat_purchase_by_orders), AGG(repeat_purchase_by_days),
       AGG(repeat_purchase_rate_by_orders), AGG(repeat_purchase_rate_by_days)
FROM repurchase
