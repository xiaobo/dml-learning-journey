SELECT AGG(active_stores), AGG(repeat_by_order), AGG(repeat_by_day),
       AGG(repeat_order_rate), AGG(repeat_day_rate)
FROM repurchase
