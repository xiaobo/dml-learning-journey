SELECT store_id, AGG(order_count), AGG(purchase_days)
FROM repurchase
GROUP BY store_id
ORDER BY store_id
