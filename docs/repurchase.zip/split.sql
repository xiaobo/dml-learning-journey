UPDATE receipts SET units=1 WHERE store_id IN ('C','D');
INSERT INTO receipts VALUES (7,'C',DATE '2025-02-03',1),(8,'D',DATE '2025-02-04',1);
