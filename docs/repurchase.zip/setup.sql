CREATE OR REPLACE TABLE receipts AS SELECT * FROM read_csv_auto('orders.csv');
