"""Run with: python verify.py --dmlc PATH (requires the duckdb Python package)."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

import duckdb

source = Path(__file__).resolve().parent


def replay(compiler, directory, scenario, expected):
    database = directory / "practice.duckdb"
    for name in ("repurchase.dml", "stores.sql", "rates.sql"):
        shutil.copyfile(source / name, directory / name)
    with duckdb.connect(str(database)) as conn:
        conn.execute("CREATE TABLE receipts AS SELECT * FROM read_csv_auto(?)", [str(source / "orders.csv")])
        if scenario == "move":
            conn.execute("UPDATE receipts SET purchase_day=DATE '2025-02-04' WHERE order_id=2")
        if scenario == "split":
            conn.execute("UPDATE receipts SET units=1 WHERE store_id IN ('C','D')")
            conn.execute("INSERT INTO receipts VALUES (7,'C',DATE '2025-02-03',1),(8,'D',DATE '2025-02-04',1)")
        if conn.execute("SELECT SUM(units) FROM receipts").fetchone()[0] != 8:
            raise ValueError("Purchase volume changed")
        oracle = conn.execute((source / "compare.sql").read_text(encoding="utf-8-sig")).fetchall()

    config = directory / ".dmlc"
    config.mkdir()
    (config / "connections.json").write_text(json.dumps({
        "connections": [{"id": "practice", "type": "duckdb", "readOnly": True,
                         "url": "jdbc:dmlc:duckdb:" + database.as_posix()}],
        "defaultConnection": "practice"
    }), encoding="utf8")

    def query(filename):
        path = directory / (filename + ".json")
        command = [compiler, "--workspace=" + str(directory), "--model=repurchase.dml",
                   "--query", "--with-validation", "--connection=practice",
                   "--output=" + str(path), filename + ".sql"]
        subprocess.run(command, cwd=directory, check=True)
        return json.loads(path.read_text(encoding="utf-8-sig"))

    stores = query("stores")
    if [(r["store_id"], r["order_count"], r["purchase_days"]) for r in stores] != [row[:3] for row in oracle]:
        raise ValueError("DML and SQL disagree on per-store counts")
    order_list = [row[0] for row in oracle if row[3]]
    day_list = [row[0] for row in oracle if row[4]]
    if (order_list, day_list) != expected:
        raise ValueError((scenario, order_list, day_list))
    rates = query("rates")
    if rates != [{"active_stores": 4, "repeat_purchase_by_orders": len(order_list), "repeat_purchase_by_days": len(day_list),
                  "repeat_purchase_rate_by_orders": len(order_list)/4, "repeat_purchase_rate_by_days": len(day_list)/4}]:
        raise ValueError((scenario, rates))
    print(scenario, order_list, day_list, rates, flush=True)
    return {"stores": stores, "rates": rates[0]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dmlc", required=True, type=Path)
    parser.add_argument("--save-results", type=Path, help="Save the checked DML query results as JSON")
    args = parser.parse_args()
    results = {}
    with tempfile.TemporaryDirectory(prefix="repeat-purchases-") as tmp:
        for name, expected in [("original", (["A", "B"], ["B"])), ("move", (["A", "B"], ["A", "B"])),
                               ("split", (["A", "B", "C", "D"], ["B"]))]:
            folder = Path(tmp) / name
            folder.mkdir()
            results[name] = replay(str(args.dmlc.resolve()), folder, name, expected)
    if args.save_results:
        args.save_results.write_bytes((json.dumps(results, indent=2) + "\n").encode("utf8"))
