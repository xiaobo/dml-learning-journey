WITH per_store AS (
    SELECT store_id, COUNT(DISTINCT order_id) AS order_count,
           COUNT(DISTINCT purchase_day) AS purchase_days
    FROM receipts
    GROUP BY store_id
    HAVING SUM(units) > 0
)
SELECT store_id, order_count, purchase_days,
       order_count > 1 AS repeat_by_order,
       purchase_days > 1 AS repeat_by_day
FROM per_store
ORDER BY store_id;
