UPDATE receipts SET purchase_day=DATE '2025-02-04' WHERE order_id=2;
