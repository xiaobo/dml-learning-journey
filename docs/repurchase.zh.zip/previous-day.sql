SELECT AGG(订单数), AGG(前一日订单数)
FROM repurchase
WHERE dt_date = '2025-02-04'
