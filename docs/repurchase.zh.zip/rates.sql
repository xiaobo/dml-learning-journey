SELECT AGG(下单门店数), AGG(按订单数算的复购门店数), AGG(按下单天数算的复购门店数),
       AGG(按订单数算的复购率), AGG(按下单天数算的复购率)
FROM repurchase
