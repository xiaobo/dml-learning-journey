SELECT 门店编号, AGG(订单数), AGG(下单天数)
FROM repurchase
GROUP BY 门店编号
ORDER BY 门店编号
