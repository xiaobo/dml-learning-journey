SELECT AGG(Bestellanzahl), AGG(BestellungenAmVortag)
FROM repurchase
WHERE dt_date = '2025-02-04'
