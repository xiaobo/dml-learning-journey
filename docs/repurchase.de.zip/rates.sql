SELECT AGG(BestellendeFilialen), AGG(WiederkäuferNachBestellanzahl), AGG(WiederkäuferNachBestelltagen),
       AGG(WiederkaufrateNachBestellanzahl), AGG(WiederkaufrateNachBestelltagen)
FROM repurchase
