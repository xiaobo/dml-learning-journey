SELECT Filialnummer, AGG(Bestellanzahl), AGG(Bestelltage)
FROM repurchase
GROUP BY Filialnummer
ORDER BY Filialnummer
