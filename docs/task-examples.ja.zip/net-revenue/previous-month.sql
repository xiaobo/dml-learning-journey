SELECT AGG(純売上高), AGG(前月の純売上高) FROM MODEL WHERE dt_month='2025-02-01'
