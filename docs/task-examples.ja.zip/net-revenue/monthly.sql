SELECT dt_month, AGG(純売上高) FROM MODEL GROUP BY dt_month ORDER BY dt_month
