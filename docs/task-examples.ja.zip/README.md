# 業務サンプルを実行する

展開したフォルダーで月別と地域別のレポートを実行します。次に、返金を差し引くモデルで同じクエリを実行します。最後のクエリでは2月と1月の純売上高を比較します。

```sh
cd net-revenue
dmlc -q setup.sql
dmlc -q --with-validation --model=model.dml monthly.sql
dmlc -q --with-validation --model=model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml monthly.sql
dmlc -q --with-validation --model=after-refunds/model.dml regional.sql
dmlc -q --with-validation --model=after-refunds/model.dml previous-month.sql
cd ..
```

五つのサンプルをまとめて照合するには、プロジェクトのフォルダーで PowerShell から次のコマンドを実行します。実行ごとに新しい出力フォルダーを指定してください。

```powershell
./verify.ps1 -Output practice-output
```

## JDBC の検証（任意）

JDK、依存ライブラリを含む dmlc の JAR、対応する DuckDB JDBC ドライバーを用意します。パスを実際の場所に置き換えてください。Unix のクラスパスはコロンで区切ります。

```powershell
java -cp "C:/path/to/dmlc-assembly.jar;C:/path/to/duckdb-jdbc.jar" jdbc/VerifyJdbc.java "$PWD/jdbc" C:/path/to/driver-directory
```
